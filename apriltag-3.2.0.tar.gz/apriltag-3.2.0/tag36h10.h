#ifndef _TAG36H10
#define _TAG36H10

#include "apriltag.h"

#ifdef __cplusplus
extern "C" {
#endif

apriltag_family_t *tag36h10_create();
void tag36h10_destroy(apriltag_family_t *tf);

#ifdef __cplusplus
}
#endif

#endif
